package com.example.localrulevpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor

// 教学用骨架：建立专用测试 TUN，不读取、转发或修改数据包。
class LocalVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("localrule", "LocalRule VPN", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
            startForeground(77, Notification.Builder(this, "localrule")
                .setContentTitle("LocalRule VPN 测试")
                .setContentText("测试隧道运行中；未转发网络流量")
                .setSmallIcon(android.R.drawable.stat_sys_download_done).build())
        }
        if (tun == null) {
            tun = Builder().setSession("LocalRule VPN Test")
                .addAddress("10.23.0.2", 32)
                .addRoute("10.23.0.1", 32)
                .setMtu(1500).establish()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
}
