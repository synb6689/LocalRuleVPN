package com.example.localrulevpn

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var rules: EditText
    private val prefs by lazy { getSharedPreferences("local_rules", MODE_PRIVATE) }
    private val requestCode = 4107
    private val starterJson = """
        {
          "enabled": true,
          "rules": [
            {
              "name": "示例测试规则",
              "match": "403508",
              "replace": "403188",
              "contentType": "application/json"
            }
          ]
        }
    """.trimIndent()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
        }
        layout.addView(TextView(this).apply { text = "LocalRule VPN"; textSize = 24f })
        status = TextView(this).apply {
            text = "状态：已停止\n这是测试骨架，不会转发或修改游戏流量。"
            setPadding(0, 16, 0, 16)
        }
        layout.addView(status)
        layout.addView(Button(this).apply {
            text = "启动本地 VPN（测试）"
            setOnClickListener {
                val prep = VpnService.prepare(this@MainActivity)
                if (prep != null) startActivityForResult(prep, requestCode) else startVpn()
            }
        })
        layout.addView(Button(this).apply {
            text = "停止 VPN"
            setOnClickListener {
                stopService(Intent(this@MainActivity, LocalVpnService::class.java))
                status.text = "状态：已停止"
            }
        })
        layout.addView(Button(this).apply {
            text = "保存本地规则"
            setOnClickListener {
                try {
                    JSONObject(rules.text.toString())
                    prefs.edit().putString("json", rules.text.toString()).apply()
                    Toast.makeText(this@MainActivity, "已保存到本机", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "JSON 格式错误：${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        })
        layout.addView(Button(this).apply {
            text = "测试字符串替换"
            setOnClickListener {
                try {
                    val root = JSONObject(rules.text.toString())
                    var value = "403508"
                    val arr = root.optJSONArray("rules")
                    if (root.optBoolean("enabled", true) && arr != null) {
                        for (i in 0 until arr.length()) {
                            val r = arr.getJSONObject(i)
                            if (r.optBoolean("enabled", true)) {
                                val old = r.optString("match")
                                if (old.isNotEmpty()) value = value.replace(old, r.optString("replace"))
                            }
                        }
                    }
                    Toast.makeText(this@MainActivity, "测试结果：$value（仅字符串测试）", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "测试失败：${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        })
        layout.addView(TextView(this).apply { text = "本地 JSON 规则：" })
        rules = EditText(this).apply {
            hint = "编辑规则 JSON"
            gravity = Gravity.TOP
            minLines = 10
            textSize = 13f
            setText(prefs.getString("json", starterJson))
        }
        layout.addView(rules, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(layout)
    }

    private fun startVpn() {
        startService(Intent(this, LocalVpnService::class.java))
        status.text = "已请求启动测试 VPN。此版本仅建立 TUN，不转发网络。"
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == this.requestCode && resultCode == RESULT_OK) startVpn()
    }
}
