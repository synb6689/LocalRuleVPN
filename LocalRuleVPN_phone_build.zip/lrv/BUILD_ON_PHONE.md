# 手机浏览器构建 APK（无需本地终端）

本项目目前是测试用骨架：VPN 服务只建立 TUN 接口，不转发或修改真实流量。

## 使用 GitHub Actions 构建
1. 在浏览器登录 GitHub，创建一个新的空仓库。
2. 将本 ZIP 解压后，把其中所有文件和 `.github/workflows/build-apk.yml` 上传到仓库根目录。注意 `.github` 是隐藏目录；若手机网页端不便上传隐藏目录，可先在仓库网页中创建 `.github/workflows/build-apk.yml`，复制本项目同名文件内容。
3. 打开仓库的 Actions 标签页，选择 “Build Android APK”，点 “Run workflow”。首次运行时按页面提示启用 Actions。
4. 等待任务成功，在该次运行页面底部 Artifacts 下载 `LocalRuleVPN-debug-apk`，解压后安装 `app-debug.apk`。

如果构建失败，打开任务日志，把红色报错文字或截图发回即可排查。

注意：这是未签名的调试 APK；安装时 Android 可能要求允许此来源安装。此版本不是可用的全流量代理，也不能保证或实现游戏皮肤修改。
