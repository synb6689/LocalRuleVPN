# LocalRule VPN starter

这是 Android Studio 项目骨架，不是已编译 APK。

包含：本地 JSON 规则编辑/保存、字符串替换测试、Android VpnService 启停授权示例。
当前 VPN 服务只建立测试 TUN 接口，不转发互联网流量，也不修改任何游戏流量。

构建：使用 Android Studio、JDK 17、Android SDK 35 打开本目录并构建 APK。
