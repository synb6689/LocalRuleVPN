package com.example.localrulevpn

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import org.json.JSONArray

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("local_rules", MODE_PRIVATE) }
    private val requestCode = 4107
    private val catalogRequestCode = 4108
    private var settingsPage = false
    private lateinit var status: TextView
    private lateinit var appSpinner: Spinner
    private lateinit var mode: RadioGroup
    private var apps: List<AppItem> = emptyList()

    private data class AppItem(val label: String, val packageName: String) {
        override fun toString() = "$label  ·  $packageName"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        apps = loadLaunchableApps()
        showHome()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) updateStatus()
    }

    private fun baseLayout(title: String): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(24))
            setBackgroundColor(Color.rgb(16, 18, 24))
            addView(TextView(this@MainActivity).apply {
                text = title
                textSize = 24f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, 0, 0, dp(12))
            })
        }
    }

    private fun showHome() {
        settingsPage = false
        val content = baseLayout("LocalRuleVPN · 本地控制面板")
        val scroll = ScrollView(this)
        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        status = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.rgb(180, 210, 190))
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.rgb(29, 36, 39))
        }
        column.addView(status, matchWrap())
        updateStatus()

        addSection(column, "连接控制")
        addAction(column, "连接 VPN", "启动本地 VPN 服务") { requestVpnStart() }
        addAction(column, "停止 VPN", "断开 VPN 并停止转发核心") { requestVpnStop() }
        addAction(column, "新开连接", "重新建立本地 VPN 连接") { requestVpnStart() }
        addAction(column, "打开游戏", "启动下方选中的应用") { launchSelectedApp() }

        addSection(column, "仓库与外观记录")
        val category = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("选择仓库类别", "本地记录", "测试记录"))
            setSelection(prefs.getInt("category", 0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    prefs.edit().putInt("category", position).apply()
                }
            }
        }
        column.addView(category, matchWrap())
        addAction(column, "本地皮肤数据库", "浏览/导入物品名称、编号与分类；不修改游戏") { showSkinCatalog() }
        addAction(column, "本次目录", "查看/记录当前目录（本地占位入口）") {
            Toast.makeText(this, "目录记录入口已预留；当前版本尚未接入文件仓库。", Toast.LENGTH_LONG).show()
        }
        addAction(column, "仓库添加：${prefs.getInt("repo_count", 0)} / 当前", "本地记录入口") {
            Toast.makeText(this, "仓库管理尚未接入真实文件导入。", Toast.LENGTH_SHORT).show()
        }
        addAction(column, "本地穿戴：01 / 脱下 0", "仅用于本地界面记录") {
            Toast.makeText(this, "这是界面记录项，不会修改游戏数据。", Toast.LENGTH_SHORT).show()
        }
        addAction(column, "服装记录：未选择", "本地记录入口") {
            Toast.makeText(this, "服装记录入口已预留。", Toast.LENGTH_SHORT).show()
        }

        addSection(column, "功能开关（仅本地记录）")
        addRecordSwitch(column, "自身外观同步")
        addRecordSwitch(column, "局内角色识别")
        addRecordSwitch(column, "内服装写入")
        addRecordSwitch(column, "局内枪皮写入")
        column.addView(TextView(this).apply {
            text = "提示：以上外观/写入开关目前只保存界面状态，不会篡改游戏流量或实际修改游戏内外观。"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(dp(4), dp(8), dp(4), dp(12))
        })
        addAction(column, "⚙ 设置与接口", "DNS、VPN 模式、应用选择、规则和日志") { showSettings() }

        scroll.addView(column)
        content.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(content)
    }

    private fun showSettings() {
        settingsPage = true
        val content = baseLayout("‹ 设置与接口")
        addAction(content, "返回首页", "") { showHome() }
        addSection(content, "DNS 设置")
        val dnsSwitch = Switch(this).apply {
            text = "启用 VPN DNS 处理"
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("dns_enabled", true)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("dns_enabled", checked).apply() }
        }
        content.addView(dnsSwitch, matchWrap())
        content.addView(TextView(this).apply {
            text = "DNS 地址（默认 1.1.1.1）"
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(8), 0, dp(4))
        })
        val dnsInput = EditText(this).apply {
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            hint = "例如 1.1.1.1"
            setSingleLine(true)
            setText(prefs.getString("dns_address", "1.1.1.1"))
        }
        content.addView(dnsInput, matchWrap())
        addAction(content, "保存 DNS 设置", "下次启动 VPN 时生效") {
            val value = dnsInput.text.toString().trim()
            if (value.isBlank() || value.any { it.isWhitespace() }) {
                Toast.makeText(this, "请输入有效的 DNS 地址", Toast.LENGTH_SHORT).show()
            } else {
                prefs.edit().putString("dns_address", value).apply()
                Toast.makeText(this, "DNS 设置已保存；请重新连接 VPN 生效", Toast.LENGTH_LONG).show()
            }
        }

        addSection(content, "VPN 接口")
        mode = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        mode.addView(RadioButton(this).apply { id = MODE_GLOBAL; text = "全局模式：所有应用"; setTextColor(Color.WHITE) })
        mode.addView(RadioButton(this).apply { id = MODE_APP; text = "指定应用模式"; setTextColor(Color.WHITE) })
        mode.check(prefs.getInt("mode", MODE_GLOBAL))
        mode.setOnCheckedChangeListener { _, checkedId ->
            prefs.edit().putInt("mode", checkedId).apply()
            if (::appSpinner.isInitialized) appSpinner.isEnabled = checkedId == MODE_APP
        }
        content.addView(mode, matchWrap())
        content.addView(TextView(this).apply {
            text = "指定应用"
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(8), 0, dp(4))
        })
        appSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, apps)
            val savedIndex = apps.indexOfFirst { it.packageName == prefs.getString("selected_app", null) }
            if (savedIndex >= 0) setSelection(savedIndex)
            isEnabled = mode.checkedRadioButtonId == MODE_APP
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    apps.getOrNull(position)?.let { prefs.edit().putString("selected_app", it.packageName).apply() }
                }
            }
        }
        content.addView(appSpinner, matchWrap())
        addAction(content, "查看诊断日志", "查看 VPN、TUN、核心与 DNS 启动阶段") {
            val msg = prefs.getString("diagnostic_log", "").orEmpty().ifBlank {
                prefs.getString("last_event", "暂无记录") ?: "暂无记录"
            }
            android.app.AlertDialog.Builder(this)
                .setTitle("LocalRuleVPN 诊断日志")
                .setMessage(msg)
                .setNeutralButton("复制日志") { _, _ ->
                    val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("LocalRuleVPN diagnostics", msg))
                    Toast.makeText(this, "日志已复制", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("清空日志") { _, _ ->
                    prefs.edit().remove("diagnostic_log").apply()
                    Toast.makeText(this, "日志已清空", Toast.LENGTH_SHORT).show()
                }
                .setPositiveButton("关闭", null).show()
        }
        addAction(content, "保存并重连", "使用当前 DNS 和应用模式") { requestVpnStart() }
        addSection(content, "规则接口")
        addAction(content, "本地 JSON 规则", "查看规则设置入口") {
            android.app.AlertDialog.Builder(this).setTitle("本地规则").setMessage("当前版本未实现对在线游戏加密流量的修改。此入口暂用于后续接入合法的本地网络规则与诊断功能。")
                .setPositiveButton("确定", null).show()
        }
        val scroll = ScrollView(this)
        scroll.addView(content)
        setContentView(scroll)
    }

    private fun showSkinCatalog() {
        val content = baseLayout("‹ 本地皮肤数据库")
        addAction(content, "返回首页", "") { showHome() }
        content.addView(TextView(this).apply {
            text = "本地目录只用于浏览和整理数据，不会解锁或修改《和平精英》中的物品。请使用你有权使用的数据来源。"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(4), 0, dp(12))
        })
        addAction(content, "导入本地 JSON 数据库", "格式示例见导入说明") {
            android.app.AlertDialog.Builder(this)
                .setTitle("数据库格式")
                .setMessage("选择 JSON 文件，格式为：{\"items\":[{\"name\":\"示例名称\",\"category\":\"枪械\",\"itemCode\":\"示例编号\",\"notes\":\"备注\"}]}。请不要把示例编号当成真实游戏物品码。")
                .setNegativeButton("取消", null)
                .setPositiveButton("选择文件") { _, _ ->
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "application/json"
                    }
                    startActivityForResult(intent, catalogRequestCode)
                }.show()
        }

        val raw = prefs.getString("skin_catalog_json", null) ?: "{\"items\":[]}"
        val items = try { JSONArray(JSONObject(raw).optJSONArray("items").toString()) } catch (_: Exception) { JSONArray() }
        val categories = mutableListOf("全部分类")
        for (i in 0 until items.length()) {
            val cat = items.optJSONObject(i)?.optString("category", "其他") ?: "其他"
            if (cat.isNotBlank() && !categories.contains(cat)) categories.add(cat)
        }
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, categories)
        }
        content.addView(spinner, matchWrap())
        val search = EditText(this).apply {
            hint = "搜索名称、物品编号或备注"
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
        }
        content.addView(search, matchWrap())
        val result = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(0, dp(12), 0, dp(12))
        }
        content.addView(result, matchWrap())
        fun refresh() {
            val query = search.text.toString().trim().lowercase()
            val category = spinner.selectedItem?.toString() ?: "全部分类"
            val lines = mutableListOf<String>()
            for (i in 0 until items.length()) {
                val item = items.optJSONObject(i) ?: continue
                val name = item.optString("name", "未命名")
                val cat = item.optString("category", "其他")
                val code = item.optString("itemCode", "")
                val notes = item.optString("notes", "")
                val haystack = "$name $cat $code $notes".lowercase()
                if ((category == "全部分类" || cat == category) && (query.isBlank() || haystack.contains(query))) {
                    lines.add("【$cat】$name\n编号：${if (code.isBlank()) "未填写" else code}${if (notes.isBlank()) "" else "\n备注：$notes"}")
                }
            }
            result.text = if (lines.isEmpty()) {
                "当前数据库没有匹配的真实物品记录。\n\n分类可包含：枪械、服装、载具、头盔、背包、其他。导入你有权使用的 JSON 数据后，这里会显示对应记录。"
            } else "记录数：${lines.size}\n\n" + lines.joinToString("\n\n────────────\n\n")
        }
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { refresh() }
        }
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { refresh() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        refresh()
        val scroll = ScrollView(this)
        scroll.addView(content)
        setContentView(scroll)
    }

    private fun addSection(parent: LinearLayout, title: String) {
        parent.addView(TextView(this).apply {
            text = title
            textSize = 16f
            setTextColor(Color.rgb(120, 180, 255))
            setPadding(dp(2), dp(16), dp(2), dp(6))
        })
    }

    private fun addAction(parent: LinearLayout, title: String, subtitle: String, action: () -> Unit) {
        val button = Button(this).apply {
            text = if (subtitle.isBlank()) title else "$title\n$subtitle"
            textSize = 14f
            gravity = Gravity.CENTER_VERTICAL or Gravity.START
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(39, 45, 57)))
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { action() }
        }
        val params = LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT)
        params.bottomMargin = dp(6)
        parent.addView(button, params)
    }

    private fun addRecordSwitch(parent: LinearLayout, label: String) {
        val toggle = Switch(this).apply {
            text = label
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("record_$label", false)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("record_$label", checked).apply() }
        }
        parent.addView(toggle, matchWrap())
    }

    private fun updateStatus() {
        if (!::status.isInitialized) return
        val running = prefs.getBoolean("vpn_running", false)
        status.text = if (running) "状态：VPN 已启动（请实际测试网络）" else "状态：已停止\n本地 VPN 直连不提供额外代理出口。"
    }

    private fun requestVpnStart() {
        val modeId = if (settingsPage && ::mode.isInitialized) mode.checkedRadioButtonId else prefs.getInt("mode", MODE_GLOBAL)
        if (modeId == MODE_APP && apps.isEmpty()) {
            Toast.makeText(this, "没有找到可选择的应用", Toast.LENGTH_LONG).show()
            return
        }
        val prep = VpnService.prepare(this)
        if (prep != null) startActivityForResult(prep, requestCode) else startVpn()
    }

    private fun requestVpnStop() {
        try {
            val i = Intent(this, LocalVpnService::class.java).setAction(LocalVpnService.ACTION_STOP)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) startService(i) else startService(i)
            prefs.edit().putString("last_event", "已发送 VPN 停止请求，正在等待服务关闭 TUN。若系统仍显示连接，请在系统 VPN 设置中手动断开。 ").apply()
            status.text = "状态：正在请求停止 VPN…"
        } catch (e: Exception) {
            prefs.edit().putString("last_event", "停止失败：${e.javaClass.simpleName}: ${e.message}").apply()
            Toast.makeText(this, "停止失败：${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun startVpn() {
        try {
            val selected = apps.getOrNull(if (::appSpinner.isInitialized) appSpinner.selectedItemPosition else -1)?.packageName
                ?: prefs.getString("selected_app", null).orEmpty()
            val modeId = if (settingsPage && ::mode.isInitialized) mode.checkedRadioButtonId else prefs.getInt("mode", MODE_GLOBAL)
            val i = Intent(this, LocalVpnService::class.java)
                .setAction(LocalVpnService.ACTION_START)
                .putExtra(LocalVpnService.EXTRA_MODE, modeId)
                .putExtra(LocalVpnService.EXTRA_APP, selected)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
            prefs.edit().putString("last_event", "已发送 VPN 启动请求。请查看系统 VPN 状态和通知。 ").apply()
            Toast.makeText(this, "已请求启动 VPN", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            prefs.edit().putBoolean("vpn_running", false).putString("last_event", "启动失败：${e.javaClass.simpleName}: ${e.message}").apply()
            Toast.makeText(this, "启动失败：${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun launchSelectedApp() {
        val selected = prefs.getString("selected_app", null)
        if (selected.isNullOrBlank()) {
            Toast.makeText(this, "请先到设置中选择应用", Toast.LENGTH_SHORT).show()
            return
        }
        val launch = packageManager.getLaunchIntentForPackage(selected)
        if (launch == null) Toast.makeText(this, "无法启动所选应用", Toast.LENGTH_SHORT).show()
        else startActivity(launch)
    }

    @Suppress("DEPRECATION")
    private fun loadLaunchableApps(): List<AppItem> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .map { AppItem(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == catalogRequestCode) {
            if (resultCode == RESULT_OK && data?.data != null) {
                try {
                    val uri = data.data!!
                    val raw = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                        ?: throw IllegalArgumentException("无法读取文件")
                    val root = JSONObject(raw)
                    if (root.optJSONArray("items") == null) throw IllegalArgumentException("缺少 items 数组")
                    prefs.edit().putString("skin_catalog_json", root.toString()).apply()
                    Toast.makeText(this, "本地数据库已导入", Toast.LENGTH_LONG).show()
                    showSkinCatalog()
                } catch (e: Exception) {
                    Toast.makeText(this, "导入失败：${e.message}", Toast.LENGTH_LONG).show()
                }
            }
            return
        }
        if (requestCode == this.requestCode) {
            if (resultCode == RESULT_OK) startVpn() else Toast.makeText(this, "VPN 授权未完成", Toast.LENGTH_SHORT).show()
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT)

    companion object {
        const val MODE_GLOBAL = 1
        const val MODE_APP = 2
    }
}
