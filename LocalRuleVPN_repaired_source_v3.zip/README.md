# LocalRuleVPN 0.3.0 — UI and VPN lifecycle update

This source update adds:
- A vertical home control panel and a separate Settings/Interfaces page.
- DNS enable/disable and upstream address preferences (applied on the next VPN start).
- Global and selected-app mode selection.
- A dedicated STOP service action that attempts to stop the core, close the TUN descriptor, remove the foreground notification, and record the result.
- Local UI toggles for the requested appearance/wardrobe labels. These currently only save UI state; they do not modify game data or encrypted game traffic.

## Important limitations

- This source has **not been built or tested on a device in this environment**. The actual forwarding behavior depends on the external EverywhereCore Android AAR and its API/build script.
- The direct outbound uses the phone's existing network. It is not a remote proxy and does not provide a separate network exit.
- If the VPN still appears connected after pressing Stop, disconnect it in Android Settings → VPN; inspect the saved log in Settings → View connection log.
- Do not assume that a successful APK build proves traffic forwarding works. Test with ordinary websites before testing any game.
