# LocalRule VPN — direct forwarding integration draft

This project now integrates a maintained Go/mobile VPN core wrapper at build time and configures sing-box with a `direct` outbound. It aims to use the phone's existing Wi-Fi/mobile data directly, without a separate SOCKS5 server. This is a direct-routing VPN, not a remote VPN/proxy service.

## App list and per-app mode
- The manifest declares launcher-intent visibility through `<queries>`, so Android 11+ can list apps that expose launcher icons without requesting broad `QUERY_ALL_PACKAGES`.
- The app picker uses `PackageManager.queryIntentActivities`.
- Global mode routes all IPv4 traffic into the VPN.
- Selected-app mode calls `VpnService.Builder.addAllowedApplication(packageName)` so only the chosen package is routed into this VPN.

## Traffic core
The app uses `EverywhereCore-Android` (`Evcore`) with sing-box and a direct outbound. Its `EverywhereCore.aar` is built in GitHub Actions and copied into `app/libs/` before Gradle builds the app. The core's socket protector is registered before start to prevent outbound socket loops.

## Limitations / verification
This integration is an implementation draft, not yet device-tested. A successful APK build does not guarantee that all DNS, UDP/QUIC, IPv6, or OEM-specific behavior works correctly. The current VPN builder routes IPv4 only; IPv6 is not captured by this initial version. Test first with a browser and disconnect if connectivity breaks. The original JSON `match/replace` control remains a local string test only; it does not inspect or rewrite encrypted app traffic.

## Build
Use the included `.github/workflows/build-from-zip.yml` workflow. It clones and builds the upstream Android core, copies the generated AAR into `app/libs/`, then runs `assembleDebug`.
