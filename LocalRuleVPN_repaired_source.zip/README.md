# LocalRuleVPN 0.5.0 — 本地皮肤目录集成版

## 本版变更
- 将用户提供的 LK 全皮肤美化 1.4.0 APK 中的皮肤目录元数据与缩略图整理为本地资源，作为离线浏览目录使用。
- 内置目录包含约 17,563 条名称/分类/编号记录，以及约 10,943 张缩略图。
- 皮肤数据库页面支持分类筛选、名称/编号搜索、分页加载（每页 40 条）和自定义 JSON 导入。
- 首次打开时默认读取 `app/src/main/assets/lk-skins/catalog.json`；导入自定义 JSON 后优先显示用户导入目录。
- 没有复制对方 APK 的 DEX/程序代码或 `libclash.so`，仅重用用户提供 APK 中的目录数据与预览缩略图，并由本项目自己的界面展示。

## 本地规则说明
对方 APK 的 `geosite.dat`、`geoip.metadb`、`ASN.mmdb` 是 Clash/Mihomo 生态的数据文件；本项目当前使用的是 sing-box/EverywhereCore 配置。它们不能只复制进 assets 就自动成为可用规则，也不应直接假定格式兼容。本版没有把这些文件伪装成已经启用的路由规则。后续需先确认核心版本和规则格式，再迁移为本地规则集。

## 重要限制
- 本地皮肤目录只用于浏览、搜索和整理，不会向游戏写入资源、绕过服务器校验或解锁未拥有物品。
- 当前 VPN 仍依赖外部 `EverywhereCore.aar` 构建产物；该 ZIP 本身不包含 AAR。GitHub Actions 会尝试从外部仓库构建它，但没有在此环境完成远程构建或手机联网实测。
- 当前 VPN 网络转发/DNS 问题尚未被证明修复；本版主要交付本地目录与缩略图功能，不应当视为已验证联网修复版。

## 自定义 JSON 格式
```json
{
  "items": [
    {"name":"示例名称","category":"枪皮","itemCode":"123","notes":"备注","thumbnail":"optional.webp"}
  ]
}
```
如果自定义条目引用缩略图，需要将图片放在 `app/src/main/assets/lk-skins/thumbs/`，并让 `thumbnail` 填写文件名。
