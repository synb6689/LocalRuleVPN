# LocalRule VPN — repaired diagnostic source

This ZIP is a rebuilt source scaffold based on the Kotlin files supplied in the conversation. I could not fetch the complete repository contents here, so this is not a verified copy of every file in the GitHub repository.

## Included
- Android Gradle project files
- Existing simple UI and local JSON string test
- VPN foreground-service startup and error handling
- Global / selected-app settings UI and app picker (saved settings only)

## Important limitation
This version only establishes a diagnostic TUN route for `10.23.0.1/32`. It **does not forward general TCP/UDP traffic to the Internet**. The global/per-app controls are saved UI settings only and do not yet affect packet routing. Do not treat this as a functioning traffic-forwarding VPN.

Real forwarding requires a maintained user-space TCP/IP packet engine integrated with Android `VpnService`, protected outbound sockets, TCP/UDP flow handling, DNS and return-packet injection. Routing `0.0.0.0/0` into the current TUN without that engine would black-hole traffic.

## Build requirements
- JDK 17
- Android SDK platform 35
- Gradle 8.7

Open in Android Studio or adapt your GitHub Actions workflow to build this project. This source has not been built or tested in this environment.
