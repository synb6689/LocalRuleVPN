package com.example.localrulevpn

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var rules: EditText
    private lateinit var mode: RadioGroup
    private lateinit var appSpinner: Spinner
    private var apps: List<AppItem> = emptyList()
    private val prefs by lazy { getSharedPreferences("local_rules", MODE_PRIVATE) }
    private val requestCode = 4107
    private data class AppItem(val label: String, val packageName: String) {
        override fun toString() = "$label  ·  $packageName"
    }

    private val starterJson = """{
      "enabled": true,
      "rules": [{"name":"示例测试规则","match":"403508","replace":"403188","contentType":"application/json"}]
    }"""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 20)
        }
        layout.addView(TextView(this).apply { text = "LocalRule VPN"; textSize = 24f })
        status = TextView(this).apply {
            text = "状态：已停止\n转发核心：sing-box direct（使用手机当前网络直连，不需要自备代理服务器）"
            setPadding(0, 10, 0, 12)
        }
        layout.addView(status)

        layout.addView(TextView(this).apply { text = "流量模式" })
        mode = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        mode.addView(RadioButton(this).apply { id = MODE_GLOBAL; text = "全局模式：所有应用通过本地 VPN" })
        mode.addView(RadioButton(this).apply { id = MODE_APP; text = "指定应用模式：仅所选应用通过本地 VPN" })
        mode.check(prefs.getInt("mode", MODE_GLOBAL))
        mode.setOnCheckedChangeListener { _, checkedId ->
            prefs.edit().putInt("mode", checkedId).apply()
            appSpinner.isEnabled = checkedId == MODE_APP
        }
        layout.addView(mode)

        layout.addView(TextView(this).apply { text = "指定应用" })
        appSpinner = Spinner(this)
        apps = loadLaunchableApps()
        appSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, apps)
        val savedIndex = apps.indexOfFirst { it.packageName == prefs.getString("selected_app", null) }
        if (savedIndex >= 0) appSpinner.setSelection(savedIndex)
        appSpinner.isEnabled = mode.checkedRadioButtonId == MODE_APP
        appSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                if (apps.isNotEmpty()) prefs.edit().putString("selected_app", apps[position].packageName).apply()
            }
        }
        layout.addView(appSpinner)
        layout.addView(TextView(this).apply {
            text = "说明：direct 模式通过手机当前 Wi-Fi/移动网络访问目标网站，不会提供额外的翻墙出口。"
            setPadding(0, 8, 0, 8)
        })

        layout.addView(Button(this).apply {
            text = "启动流量转发"
            setOnClickListener {
                if (mode.checkedRadioButtonId == MODE_APP && apps.isEmpty()) {
                    status.text = "未找到可选择的应用。"
                    return@setOnClickListener
                }
                val prep = VpnService.prepare(this@MainActivity)
                if (prep != null) startActivityForResult(prep, requestCode) else startVpn()
            }
        })
        layout.addView(Button(this).apply {
            text = "停止 VPN"
            setOnClickListener {
                stopService(Intent(this@MainActivity, LocalVpnService::class.java))
                status.text = "状态：已停止"
            }
        })
        layout.addView(Button(this).apply {
            text = "保存本地规则"
            setOnClickListener {
                try {
                    JSONObject(rules.text.toString())
                    prefs.edit().putString("json", rules.text.toString()).apply()
                    Toast.makeText(this@MainActivity, "已保存到本机", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "JSON 格式错误：${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        })
        layout.addView(Button(this).apply {
            text = "测试字符串替换"
            setOnClickListener {
                try {
                    val root = JSONObject(rules.text.toString())
                    var value = "403508"
                    val arr = root.optJSONArray("rules")
                    if (root.optBoolean("enabled", true) && arr != null) {
                        for (i in 0 until arr.length()) {
                            val r = arr.getJSONObject(i)
                            if (r.optBoolean("enabled", true)) {
                                val old = r.optString("match")
                                if (old.isNotEmpty()) value = value.replace(old, r.optString("replace"))
                            }
                        }
                    }
                    Toast.makeText(this@MainActivity, "测试结果：$value（仅字符串测试）", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "测试失败：${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        })
        layout.addView(TextView(this).apply { text = "本地 JSON 规则：" })
        rules = EditText(this).apply {
            hint = "编辑规则 JSON"; gravity = Gravity.TOP; minLines = 5; textSize = 13f
            setText(prefs.getString("json", starterJson))
        }
        layout.addView(rules, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(layout)
    }

    @Suppress("DEPRECATION")
    private fun loadLaunchableApps(): List<AppItem> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .map { AppItem(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    private fun startVpn() {
        try {
            val selected = apps.getOrNull(appSpinner.selectedItemPosition)?.packageName
                ?: prefs.getString("selected_app", null).orEmpty()
            val i = Intent(this, LocalVpnService::class.java)
                .putExtra(LocalVpnService.EXTRA_MODE, mode.checkedRadioButtonId)
                .putExtra(LocalVpnService.EXTRA_APP, selected)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) startForegroundService(i)
            else startService(i)
            status.text = "已请求启动。请查看 VPN 通知；如果核心启动失败，服务会停止并记录错误。"
        } catch (e: Exception) {
            status.text = "启动失败：${e.javaClass.simpleName}: ${e.message}"
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == this.requestCode) {
            if (resultCode == RESULT_OK) startVpn() else status.text = "VPN 授权未完成，未启动。"
        }
    }

    companion object {
        const val MODE_GLOBAL = 1
        const val MODE_APP = 2
    }
}
