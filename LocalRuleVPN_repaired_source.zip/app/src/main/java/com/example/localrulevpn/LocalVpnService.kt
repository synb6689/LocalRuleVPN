package com.example.localrulevpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import com.argsment.everywhere.evcore.Evcore
import com.argsment.everywhere.evcore.Protector

/**
 * Uses the EverywhereCore sing-box wrapper with a direct outbound.
 * All routed traffic goes directly through the phone's existing network; no remote proxy is configured.
 */
class LocalVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null
    private val channelId = "localrule"
    private var coreStarted = false
    private var coreStartAttempted = false

    private fun recordEvent(message: String, error: Throwable? = null) {
        if (error != null) Log.e(TAG, message, error) else Log.i(TAG, message)
        getSharedPreferences("local_rules", MODE_PRIVATE).edit()
            .putString("last_event", message + if (error != null) "\n${error.javaClass.simpleName}: ${error.message}" else "")
            .putLong("last_event_time", System.currentTimeMillis())
            .apply()
    }

    private inner class ServiceProtector : Protector {
        override fun protect(fd: Int): Boolean = this@LocalVpnService.protect(fd)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            try {
                stopCoreAndTun()
                getSharedPreferences("local_rules", MODE_PRIVATE).edit()
                    .putBoolean("vpn_running", false)
                    .putString("last_event", "VPN 已停止；TUN 已关闭。")
                    .apply()
            } catch (e: Exception) {
                recordEvent("VPN 停止失败", e)
                getSharedPreferences("local_rules", MODE_PRIVATE).edit()
                    .putBoolean("vpn_running", false)
                    .putString("last_event", "停止过程中出错：${e.javaClass.simpleName}: ${e.message}")
                    .apply()
            } finally {
                stopForegroundCompat()
                stopSelf(startId)
            }
            return START_NOT_STICKY
        }
        try {
            createNotificationChannel()
            val notificationBuilder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                Notification.Builder(this, channelId) else {
                @Suppress("DEPRECATION") Notification.Builder(this)
            }
            val notification = notificationBuilder
                .setContentTitle("LocalRule VPN")
                .setContentText("正在初始化本地流量转发")
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setOngoing(true).build()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                startForeground(77, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else startForeground(77, notification)

            stopCoreAndTun()

            val mode = intent?.getIntExtra(EXTRA_MODE, MainActivity.MODE_GLOBAL) ?: MainActivity.MODE_GLOBAL
            val selectedApp = intent?.getStringExtra(EXTRA_APP).orEmpty()
            val prefs = getSharedPreferences("local_rules", MODE_PRIVATE)
            val dnsEnabled = prefs.getBoolean("dns_enabled", true)
            recordEvent("准备建立 VPN：DNS=${if (dnsEnabled) "启用" else "关闭"}，模式=${if (mode == MainActivity.MODE_APP) "指定应用" else "全局"}。")
            val dnsAddress = prefs.getString("dns_address", "1.1.1.1")?.trim().orEmpty().ifBlank { "1.1.1.1" }
            val builder = Builder()
                .setSession("LocalRule VPN Direct")
                .setMtu(MTU)
                .addAddress("172.19.0.1", 30)
                .addRoute("0.0.0.0", 0)
            if (dnsEnabled) builder.addDnsServer("172.19.0.2")

            if (mode == MainActivity.MODE_APP) {
                if (selectedApp.isBlank()) throw IllegalArgumentException("指定应用模式未选择应用")
                builder.addAllowedApplication(selectedApp)
            }

            recordEvent("正在建立 Android TUN 接口。")
            val pfd = builder.establish() ?: throw IllegalStateException("VPN 授权已失效，无法建立 TUN")
            tun = pfd
            recordEvent("Android TUN 已建立，fd=${pfd.fd}，MTU=$MTU。")

            // DNS interception is optional. The configured upstream is escaped as JSON.
            val dnsConfig = if (dnsEnabled) "\"dns\":{\"servers\":[{\"type\":\"udp\",\"tag\":\"dns-direct\",\"server\":${org.json.JSONObject.quote(dnsAddress)}}],\"final\":\"dns-direct\"}," else ""
            val dnsRule = if (dnsEnabled) "{\"protocol\":\"dns\",\"action\":\"hijack-dns\"}" else ""
            val routeRules = if (dnsRule.isNotEmpty()) "\"rules\":[$dnsRule]," else ""
            val config = """
                {
                  "log": {"level": "info", "timestamp": true},
                  $dnsConfig
                  "inbounds": [
                    {
                      "type": "tun",
                      "tag": "tun-in",
                      "address": ["172.19.0.1/30"],
                      "mtu": $MTU,
                      "auto_route": false,
                      "strict_route": false,
                      "stack": "mixed"
                    }
                  ],
                  "outbounds": [
                    {"type": "direct", "tag": "direct"}
                  ],
                  "route": {
                    $routeRules
                    "auto_detect_interface": true,
                    "final": "direct"
                  }
                }
            """.trimIndent()

            recordEvent("DNS/路由配置已生成；DNS 上游=${if (dnsEnabled) dnsAddress else "系统默认（未配置 VPN DNS）"}。正在启动 sing-box 核心。")
            Evcore.setSocketProtector(ServiceProtector())
            Evcore.setResourcesPath(noBackupFilesDir.absolutePath)
            coreStartAttempted = true
            Evcore.startCore("singbox", config, pfd.fd.toLong(), MTU.toLong())
            coreStarted = true
            recordEvent("Evcore.startCore 已返回；这只表示启动调用返回，不代表 DNS/网页已验证成功。")
            getSharedPreferences("local_rules", MODE_PRIVATE).edit()
                .putBoolean("vpn_running", true)
                .putString("last_event", "核心启动调用已返回；尚未验证真实网络。模式=${if (mode == MainActivity.MODE_APP) "指定应用" else "全局"}，DNS=${if (dnsEnabled) dnsAddress else "关闭"}。")
                .putLong("last_event_time", System.currentTimeMillis())
                .apply()

            val manager = getSystemService(NotificationManager::class.java)
            manager.notify(77, notificationBuilder
                .setContentText(if (mode == MainActivity.MODE_APP) "指定应用模式：$selectedApp" else "全局模式：本地网络直连")
                .build())
            return START_NOT_STICKY
        } catch (e: Exception) {
            recordEvent("VPN/核心启动失败", e)
            stopCoreAndTun()
            getSharedPreferences("local_rules", MODE_PRIVATE).edit()
                .putBoolean("vpn_running", false)
                .putString("last_event", "启动失败：${e.javaClass.simpleName}: ${e.message}")
                .putLong("last_event_time", System.currentTimeMillis())
                .apply()
            stopForegroundCompat()
            stopSelf()
            return START_NOT_STICKY
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            if (manager.getNotificationChannel(channelId) == null) {
                manager.createNotificationChannel(NotificationChannel(
                    channelId, "LocalRule VPN", NotificationManager.IMPORTANCE_LOW))
            }
        }
    }

    private fun stopCoreAndTun() {
        // stopAll is attempted even if startCore threw part-way through; otherwise a partial
        // core startup can keep sockets/threads alive while the Android TUN is being closed.
        if (coreStarted || coreStartAttempted) {
            try {
                recordEvent("正在请求停止 sing-box 核心。")
                Evcore.stopAll()
                recordEvent("Evcore.stopAll 已返回。")
            } catch (e: Exception) {
                recordEvent("停止核心时发生异常", e)
            } finally {
                coreStarted = false
                coreStartAttempted = false
            }
        }
        try {
            tun?.close()
            recordEvent("TUN 文件描述符已关闭。")
        } catch (e: Exception) {
            recordEvent("关闭 TUN 时发生异常", e)
        }
        tun = null
    }

    private fun stopForegroundCompat() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE)
        else {
            @Suppress("DEPRECATION") stopForeground(true)
        }
    }

    override fun onRevoke() {
        // Android calls this when the user revokes VPN permission or disconnects it in system settings.
        try {
            stopCoreAndTun()
        } finally {
            getSharedPreferences("local_rules", MODE_PRIVATE).edit()
                .putBoolean("vpn_running", false)
                .putString("last_event", "系统已撤销 VPN；流量核心与 TUN 已请求关闭。")
                .putLong("last_event_time", System.currentTimeMillis())
                .apply()
            stopForegroundCompat()
            stopSelf()
        }
        super.onRevoke()
    }

    override fun onDestroy() {
        stopCoreAndTun()
        getSharedPreferences("local_rules", MODE_PRIVATE).edit()
            .putBoolean("vpn_running", false)
            .putString("last_event", "VPN 服务已销毁，TUN 已关闭。")
            .putLong("last_event_time", System.currentTimeMillis())
            .apply()
        stopForegroundCompat()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.example.localrulevpn.action.START"
        const val ACTION_STOP = "com.example.localrulevpn.action.STOP"
        const val EXTRA_MODE = "mode"
        const val EXTRA_APP = "selected_app"
        private const val TAG = "LocalRuleVPN"
        private const val MTU = 1500
    }
}
