package com.example.localrulevpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import com.argsment.everywhere.evcore.Evcore
import com.argsment.everywhere.evcore.Protector

/**
 * Uses the EverywhereCore sing-box wrapper with a direct outbound.
 * All routed traffic goes directly through the phone's existing network; no remote proxy is configured.
 */
class LocalVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null
    private val channelId = "localrule"
    private var coreStarted = false

    private inner class ServiceProtector : Protector {
        override fun protect(fd: Int): Boolean = this@LocalVpnService.protect(fd)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            try {
                stopCoreAndTun()
                getSharedPreferences("local_rules", MODE_PRIVATE).edit()
                    .putBoolean("vpn_running", false)
                    .putString("last_event", "VPN 已停止；TUN 已关闭。")
                    .apply()
            } catch (e: Exception) {
                Log.e(TAG, "VPN stop failed", e)
                getSharedPreferences("local_rules", MODE_PRIVATE).edit()
                    .putBoolean("vpn_running", false)
                    .putString("last_event", "停止过程中出错：${e.javaClass.simpleName}: ${e.message}")
                    .apply()
            } finally {
                stopForegroundCompat()
                stopSelf(startId)
            }
            return START_NOT_STICKY
        }
        try {
            createNotificationChannel()
            val notificationBuilder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                Notification.Builder(this, channelId) else {
                @Suppress("DEPRECATION") Notification.Builder(this)
            }
            val notification = notificationBuilder
                .setContentTitle("LocalRule VPN")
                .setContentText("正在初始化本地流量转发")
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setOngoing(true).build()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                startForeground(77, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else startForeground(77, notification)

            stopCoreAndTun()

            val mode = intent?.getIntExtra(EXTRA_MODE, MainActivity.MODE_GLOBAL) ?: MainActivity.MODE_GLOBAL
            val selectedApp = intent?.getStringExtra(EXTRA_APP).orEmpty()
            val prefs = getSharedPreferences("local_rules", MODE_PRIVATE)
            val dnsEnabled = prefs.getBoolean("dns_enabled", true)
            val dnsAddress = prefs.getString("dns_address", "1.1.1.1")?.trim().orEmpty().ifBlank { "1.1.1.1" }
            val builder = Builder()
                .setSession("LocalRule VPN Direct")
                .setMtu(MTU)
                .addAddress("172.19.0.1", 30)
                .addRoute("0.0.0.0", 0)
            if (dnsEnabled) builder.addDnsServer("172.19.0.2")

            if (mode == MainActivity.MODE_APP) {
                if (selectedApp.isBlank()) throw IllegalArgumentException("指定应用模式未选择应用")
                builder.addAllowedApplication(selectedApp)
            }

            val pfd = builder.establish() ?: throw IllegalStateException("VPN 授权已失效，无法建立 TUN")
            tun = pfd

            // DNS interception is optional. The configured upstream is escaped as JSON.
            val dnsConfig = if (dnsEnabled) "\"dns\":{\"servers\":[{\"type\":\"udp\",\"tag\":\"dns-direct\",\"server\":${org.json.JSONObject.quote(dnsAddress)}}],\"final\":\"dns-direct\"}," else ""
            val dnsRule = if (dnsEnabled) "{\"protocol\":\"dns\",\"action\":\"hijack-dns\"}" else ""
            val routeRules = if (dnsRule.isNotEmpty()) "\"rules\":[$dnsRule]," else ""
            val config = """
                {
                  "log": {"level": "info", "timestamp": true},
                  $dnsConfig
                  "inbounds": [
                    {
                      "type": "tun",
                      "tag": "tun-in",
                      "address": ["172.19.0.1/30"],
                      "mtu": $MTU,
                      "auto_route": false,
                      "strict_route": false,
                      "stack": "mixed"
                    }
                  ],
                  "outbounds": [
                    {"type": "direct", "tag": "direct"}
                  ],
                  "route": {
                    $routeRules
                    "auto_detect_interface": true,
                    "final": "direct"
                  }
                }
            """.trimIndent()

            Evcore.setSocketProtector(ServiceProtector())
            Evcore.setResourcesPath(noBackupFilesDir.absolutePath)
            Evcore.startCore("singbox", config, pfd.fd.toLong(), MTU.toLong())
            coreStarted = true
            getSharedPreferences("local_rules", MODE_PRIVATE).edit()
                .putBoolean("vpn_running", true)
                .putString("last_event", "VPN 核心已启动；模式=${if (mode == MainActivity.MODE_APP) "指定应用" else "全局"}，DNS=${if (dnsEnabled) dnsAddress else "关闭"}。")
                .apply()

            val manager = getSystemService(NotificationManager::class.java)
            manager.notify(77, notificationBuilder
                .setContentText(if (mode == MainActivity.MODE_APP) "指定应用模式：$selectedApp" else "全局模式：本地网络直连")
                .build())
            return START_NOT_STICKY
        } catch (e: Exception) {
            Log.e(TAG, "VPN/core start failed", e)
            stopCoreAndTun()
            getSharedPreferences("local_rules", MODE_PRIVATE).edit()
                .putBoolean("vpn_running", false)
                .putString("last_event", "启动失败：${e.javaClass.simpleName}: ${e.message}")
                .apply()
            stopForegroundCompat()
            stopSelf()
            return START_NOT_STICKY
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            if (manager.getNotificationChannel(channelId) == null) {
                manager.createNotificationChannel(NotificationChannel(
                    channelId, "LocalRule VPN", NotificationManager.IMPORTANCE_LOW))
            }
        }
    }

    private fun stopCoreAndTun() {
        if (coreStarted) {
            try { Evcore.stopAll() } catch (e: Exception) { Log.w(TAG, "Stopping core failed", e) }
            coreStarted = false
        }
        try { tun?.close() } catch (e: Exception) { Log.w(TAG, "Closing TUN failed", e) }
        tun = null
    }

    private fun stopForegroundCompat() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE)
        else {
            @Suppress("DEPRECATION") stopForeground(true)
        }
    }

    override fun onRevoke() {
        // Android calls this when the user revokes VPN permission or disconnects it in system settings.
        try {
            stopCoreAndTun()
        } finally {
            getSharedPreferences("local_rules", MODE_PRIVATE).edit()
                .putBoolean("vpn_running", false)
                .putString("last_event", "系统已撤销 VPN；流量核心与 TUN 已请求关闭。")
                .apply()
            stopForegroundCompat()
            stopSelf()
        }
        super.onRevoke()
    }

    override fun onDestroy() {
        stopCoreAndTun()
        getSharedPreferences("local_rules", MODE_PRIVATE).edit()
            .putBoolean("vpn_running", false)
            .putString("last_event", "VPN 服务已销毁，TUN 已关闭。")
            .apply()
        stopForegroundCompat()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.example.localrulevpn.action.START"
        const val ACTION_STOP = "com.example.localrulevpn.action.STOP"
        const val EXTRA_MODE = "mode"
        const val EXTRA_APP = "selected_app"
        private const val TAG = "LocalRuleVPN"
        private const val MTU = 1500
    }
}
