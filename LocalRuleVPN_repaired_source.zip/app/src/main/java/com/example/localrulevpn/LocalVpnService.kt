package com.example.localrulevpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log

/** Diagnostic-only TUN service. It does not relay TCP/UDP traffic to the Internet. */
class LocalVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null
    private val channelId = "localrule"

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val manager = getSystemService(NotificationManager::class.java)
                if (manager.getNotificationChannel(channelId) == null) {
                    manager.createNotificationChannel(NotificationChannel(
                        channelId, "LocalRule VPN", NotificationManager.IMPORTANCE_LOW))
                }
            }
            val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                Notification.Builder(this, channelId) else {
                @Suppress("DEPRECATION") Notification.Builder(this)
            }
            val notification = builder.setContentTitle("LocalRule VPN 诊断测试")
                .setContentText("测试隧道运行中；未转发网络流量")
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setOngoing(true).build()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(77, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else startForeground(77, notification)

            if (tun == null) {
                tun = Builder().setSession("LocalRule VPN Test")
                    .addAddress("10.23.0.2", 32)
                    // Deliberately not a default route: avoids black-holing all Internet traffic.
                    .addRoute("10.23.0.1", 32).setMtu(1500).establish()
                if (tun == null) {
                    stopSelf()
                    return START_NOT_STICKY
                }
            }
            return START_NOT_STICKY
        } catch (e: Exception) {
            Log.e("LocalRuleVPN", "VPN service failed to start", e)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE)
            else {
                @Suppress("DEPRECATION") stopForeground(true)
            }
            stopSelf()
            return START_NOT_STICKY
        }
    }

    override fun onDestroy() {
        try { tun?.close() } catch (e: Exception) { Log.w("LocalRuleVPN", "Closing TUN failed", e) }
        tun = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE)
        else {
            @Suppress("DEPRECATION") stopForeground(true)
        }
        super.onDestroy()
    }
}
